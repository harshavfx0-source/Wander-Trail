
// ========================================
// WANDERTRAIL - TELANGANA TOURISM
// ========================================

const app = document.getElementById("app");

const places = [
    {
        id: 1, name: "Charminar", district: "Hyderabad",
        circuit: "Heritage", lat: 17.3616, lng: 78.4747,
        description: "Hyderabad's iconic monument, known for its four grand minarets and historic surroundings.",
        image: "https://imgs.search.brave.com/j8q4RdfZOGrCLT4JMtgR1MwK5LvQgo9dHCvzD6xgTQQ/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9pbWcu/bWFnbmlmaWMuY29t/L3ByZW1pdW0tcGhv/dG8vY2hhcm1pbmFy/LW1vbnVtZW50LWR1/c2std2l0aC1jcm93/ZC1tYXJrZXQtYWN0/aXZpdHlfMTE3OTE0/Ni00MTM5NS5qcGc_/c2VtdD1haXNfaHli/cmlkJnc9NzQwJnE9/ODA",
        gallery: [
            "https://imgs.search.brave.com/ZUvIMleZM04VS27VSVbpUBC0SLZKXVzrJMRg2txFd5g/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly90aHVt/YnMuZHJlYW1zdGlt/ZS5jb20vYi9pbmRp/YS1oeWRlcmFiYWQt/Y2hhcm1pbmFyLW9s/ZC1jaXR5LWhpc3Rv/cmljLXVyYmFuLWxh/bmRtYXJrLXZpZXct/YWktZ2VuZXJhdGVk/LWNoYXJtaW5hci1h/bmNob3JzLWh5ZGVy/YWJhZC1vbGQtY2l0/eS10aWdodGx5LTQ3/NTU1MDk0NC5qcGc?w=800",
            "https://imgs.search.brave.com/lx830cGaVATne94bJ5Z7aQ5PYpmkWbLpLpKuCifMEeU/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9tZWRp/YS5pc3RvY2twaG90/by5jb20vaWQvMTIx/NTI3NDk5MC9waG90/by9oaWdoLXdpZGUt/YW5nbGUtdmlldy1v/Zi1jaGFybWluYXIt/aW4tdGhlLW5pZ2h0/LmpwZz9zPTYxMng2/MTImdz0wJms9MjAm/Yz1ieXlJanFnYnNs/Zi1MMTkxbjZTSnUw/czM1ZnZOb1ZlV3N4/VjVySVBLN1NrPQ?w=800",
            "https://imgs.search.brave.com/ITCPJ9N76GDIUefsFdovQZ2D7-2myDu5pc7sa5lLTeQ/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly90My5m/dGNkbi5uZXQvanBn/LzE5LzM4LzAyLzg0/LzM2MF9GXzE5Mzgw/Mjg0NTdfNFZCWVIy/cUZuNjF4WnBqSklr/VlZySnlqWW1ZZXVp/TEQuanBn?w=800"
        ]
    },
    {
        id: 2, name: "Golconda Fort", district: "Hyderabad",
        circuit: "Fort", lat: 17.3833, lng: 78.4011,
        description: "A historic fortress famous for its architecture, royal history and acoustic engineering.",
        image: "https://imgs.search.brave.com/-ps3fZOkvTXtp9vwJjaoR9cHBzAGgfKvB8LHaB8IiwA/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9hc3Nl/dHMuY250cmF2ZWxs/ZXIuaW4vcGhvdG9z/LzYzYWQ3YTM3NWMz/MDhkMmY5NmUxNjI0/ZC9tYXN0ZXIvd18x/NjAwLGNfbGltaXQv/R2V0dHlJbWFnZXMt/NDYwNjYzNDE0Lmpw/Zw?w=800",
        gallery: [
            "https://imgs.search.brave.com/qczotwb8rSOkO1qVG0wPx_O1ErIQK3FuFW00bxNrPDs/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly93d3cu/Y2FwdHVyZWF0cmlw/LmNvbS9fbmV4dC9p/bWFnZT91cmw9aHR0/cHM6Ly9kMXp2Y21o/eXBlYXd4ai5jbG91/ZGZyb250Lm5ldC9i/bG9ncy9jb3Zlcl93/ZWIvZ29sY29uZGEt/Zm9ydC13ZWJwLTQ0/NDViZGFlMmUtMTc2/Nzk1Mjc1NDQzNi53/ZWJwJnc9Mzg0MCZx/PTc1?w=800",
            "https://imgs.search.brave.com/1JTKq5BKRiEMybz9NeVvBwtv4WxqLPpBv7prTociB24/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9oaW5k/dW1hbmRpcnlhdHJh/LmNvbS9fbmV4dC9z/dGF0aWMvbWVkaWEv/dGVtcGxlLW92ZXJ2/aWV3LjY3Yzc1MmYx/LndlYnA?w=800",
            "https://imgs.search.brave.com/f8WW-LkYXiaFfANbVz-LqJ0HAk6VyDtO4FqNC6lKqRY/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9zN2Fw/MS5zY2VuZTcuY29t/L2lzL2ltYWdlL2lu/Y3JlZGlibGVpbmRp/YS9nb2xjb25kYS1m/b3J0LWh5ZGVyYWJh/ZC1zZWN1bmRlcmFi/YWQtdGVsYW5nYW5h/LTgtbXVzdGhlYWQt/aGVybz9xbHQ9ODIm/dHM9MTc0MjE5NTY0/MTEwOQ?w=800"
        ]
    },
    {
        id: 3, name: "Ramappa Temple", district: "Mulugu",
        circuit: "Temple", lat: 18.2594, lng: 79.9433,
        description: "A UNESCO World Heritage Site celebrated for remarkable Kakatiya craftsmanship.",
        image: "https://imgs.search.brave.com/KbRvXm3JD53UU3983hC38bhKx4P--VoVY_qfp3qTz80/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9tZWRp/YS5oaXRleC5jby5p/bi9wb3N0cy8yMDIy/L3RlbGFuZ2FuYXMt/Zmlyc3Qtd29ybGQt/aGVyaXRhZ2Utc2l0/ZS1yYW1hcHBhLXRl/bXBsZS5qcGc_MTY2/OTAyODg4Ng",
        gallery: [
            "https://imgs.search.brave.com/3HF7-F5WoOjISrX-iPonibjUtPZNa85fOZbAoHJZm30/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9zdGF0/aWMud2l4c3RhdGlj/LmNvbS9tZWRpYS9m/MzFlNDRfYzA0YWZi/NjAwNTQ4NGQzZmJi/MmE3NDA1ZDg3NWM5/ZTJ-bXYyLmpwZy92/MS9maWxsL3dfOTgw/LGhfNjUzLGFsX2Ms/cV84NSx1c21fMC42/Nl8xLjAwXzAuMDEs/ZW5jX2F2aWYscXVh/bGl0eV9hdXRvL2Yz/MWU0NF9jMDRhZmI2/MDA1NDg0ZDNmYmIy/YTc0MDVkODc1Yzll/Mn5tdjIuanBn",
            "https://imgs.search.brave.com/CgRveLiURRGTUKPlCqFPCrqcOtcJRL0q-naE5jv06g0/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly91cGxv/YWQud2lraW1lZGlh/Lm9yZy93aWtpcGVk/aWEvY29tbW9ucy8x/LzEyL1JhbWFwcGFf/VGVtcGxlXzguanBn?w=800",
            "https://imgs.search.brave.com/aP8DIE3VrY2kLppqIivg4mupogxmO1Gas-4PwAGMuyY/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9pbWdz/LmV0dmJoYXJhdC5j/b20vZXR2YmhhcmF0/L3Byb2QtaW1hZ2Vz/LzEyNTg5MzMxX3Jh/bWFwcGE0LmpwZw?w=800"
        ]
    },
    {
        id: 4, name: "Warangal Fort", district: "Warangal",
        circuit: "Fort", lat: 17.9689, lng: 79.5951,
        description: "Explore the stone gateways and architectural legacy of the Kakatiya dynasty.",
        image: "https://imgs.search.brave.com/G6yXNMthmtCxiXi6iVH8pzQyRNuE8cuCkFmIhNNPWHU/rs:fit:500:0:1:0/g:ce/aHR0cDovL3d3dy5k/c291cmNlLmluL3Np/dGVzL2RlZmF1bHQv/ZmlsZXMvc3R5bGVz/L21pbmlfcmVzcG9u/c2l2ZWN1c3RvbV91/c2VyX21vYmxpZV8x/eC9wdWJsaWMvcmVz/b3VyY2Uvd2FyYW5n/YWwtZm9ydC1hbmQt/dGVtcGxlLWFyY2hp/dGVjdHVyZS93YXJh/bmdhbC1mb3J0L21p/bmlnYWxsZXJ5LzEy/OTg5L0RTQ18wNTcy/LmpwZz9pdG9rPXcz/RmVuemVWJnRpbWVz/dGFtcD0xNDU5MjQ0/MTUx?w=800",
        gallery: [
            "https://imgs.search.brave.com/qq7NXJcpxMbFU_DHPHb-67eUKBLbP7SvjEhHy8KGE0M/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly90aGV3/YXJhbmdhbC5jb20v/d3AtY29udGVudC91/cGxvYWRzLzIwMjMv/MDgvd2FyYW5nYWwt/Zm9ydC5qcGc?w=800",
            "https://imgs.search.brave.com/bKswv204v1dmDD2miJiuHxE-2CKTNtipsZhuthhgg_A/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly93d3cu/dHJvZGx5LmNvbS9p/bWFnZS9hdHRyYWN0/aW9uL3NpemUtODAw/eDUwMC9tb2RlLWNy/b3AvMjIyMS5qcGc?w=800",
            "https://imgs.search.brave.com/WTA57s8y-pytPwrKkuxLNieDlEJf73uVA5gFzw6lXGw/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9tZWRp/YS5pc3RvY2twaG90/by5jb20vaWQvMTAw/Nzg0MDYyMC9waG90/by9ydWlucy10ZW1w/bGUtY29tcGxleC13/YXJhbmdhbC1mb3J0/LXdhcmFuZ2FsLXRl/bGFuZ2FuYS1pbmRp/YS5qcGc_cz02MTJ4/NjEyJnc9MCZrPTIw/JmM9Z3ljdWdQOUN1/ajVKRjBiSHA3Umtq/RmRlREFHSVIzNkhN/dVRsa0NLbnBhUT0?w=800"
        ]
    },
    {
        id: 5, name: "Thousand Pillar Temple", district: "Warangal",
        circuit: "Temple", lat: 17.9957, lng: 79.5800,
        description: "A historic temple known for intricate pillars and Kakatiya architecture.",
        image: "https://imgs.search.brave.com/3s6HION7hpWvLv5ohPIrIBy7egzm4ym08rL_RTLogFI/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9jZi1p/bWFnZXMuYXNzZXR0/eXBlLmNvbS9UTklF/L2ltcG9ydC8yMDIx/LzExLzI1L29yaWdp/bmFsL0FmdGVyXy5q/cGc_dz00ODAmYXV0/bz1mb3JtYXQsY29t/cHJlc3MmZml0PW1h/eA?w=1200",
        gallery: [
            "https://imgs.search.brave.com/xER27sgpfX2_Q35ih082HdaJLMWebqPS7GN-gb6WTbk/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly93d3cu/ZHNvdXJjZS5pbi9z/aXRlcy9kZWZhdWx0/L2ZpbGVzL3N0eWxl/cy9taW5pX3Jlc3Bv/bnNpdmVjdXN0b21f/dXNlcl9tb2JsaWVf/MXgvcHVibGljL3Jl/c291cmNlL3dhcmFu/Z2FsLWZvcnQtYW5k/LXRlbXBsZS1hcmNo/aXRlY3R1cmUvdGhv/dXNhbmQtcGlsbGFy/LXRlbXBsZS9taW5p/Z2FsbGVyeS8xMjk5/Mi9EU0NfMDc3NC5q/cGc_aXRvaz1oOHU0/bDk3USZ0aW1lc3Rh/bXA9MTQ1OTI0ODM5/Ng?w=1200",
            "https://imgs.search.brave.com/yCtk_BwsF4aVyLqYzv2G2ULdvrEb8mxmKwXr5txSNy8/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9ibG9n/Z2VyLmdvb2dsZXVz/ZXJjb250ZW50LmNv/bS9pbWcvYi9SMjl2/WjJ4bC9BVnZYc0Vq/bEJWYmVxSFo3a2E4/V1J4ZUFGQURYRjFZ/V0hoeWVTUTZpc1N3/dlF3OTh0SXFQS1JY/OG1QZ0UtVXBDU0xa/UktnZ0p0WDNNY1Nv/MnFPVDltLUs5VFBT/OEZ0YTJ3U3IxSDhI/cVozNUJGQ2h2Z09K/d3o4aXlnWVR2X184/UjBGMzU4Ql9feGFi/MzRITWtwUS15L3M2/NDAvVGhvdXNhbmQr/cGlsbGFyK1dhcmFu/Z2FsKzUuanBn?w=800",
            "https://imgs.search.brave.com/T4EjjwXIQAmELs9Mg5tr2kG8RgfTYcgS0MKhsD8Z0po/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9pbmRp/YW5vLnRyYXZlbC93/cC1jb250ZW50L3Vw/bG9hZHMvMjAyMi8w/Ni9XaGl0ZS1TbGF0/ZS1HcmV5LUNvbXBh/bnktRHluYW1pYy1O/ZW9ucy1Db21wYW55/LVdlYnNpdGUtMTU5/MC0lQzMlOTctMTA1/MC1weC0xMDYwLSVD/MyU5Ny03MDAtcHgt/MTU5MC0lQzMlOTct/MTA1MC1weC0xLmpw/Zw?w=800"
            
        ]
    },
    {
        id: 6, name: "Bhongir Fort", district: "Yadadri",
        circuit: "Fort", lat: 17.5150, lng: 78.8850,
        description: "A hilltop fortress with panoramic views and a fascinating history.",
        image: "https://imgs.search.brave.com/HdcHsGA1T_zwBKnbllMpIECCWDtrzdCF3mUKY9Eyr3Y/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9hc3Nl/dHMudHJhdmVsdHJp/YW5nbGUuY29tL2Js/b2cvd3AtY29udGVu/dC91cGxvYWRzLzIw/MjQvMTEvRG9taW5h/dGluZy10aGUtTGFu/ZHNjYXBlLmpwZw?w=800",
        gallery: [
            "https://imgs.search.brave.com/zSKtApCSkEHo8gpeuofLAhGSARGGjwKMHjNAxW2cLeQ/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly91cGxv/YWQud2lraW1lZGlh/Lm9yZy93aWtpcGVk/aWEvY29tbW9ucy80/LzQ5L0Job25naXIu/anBn?w=800",
            "https://imgs.search.brave.com/mskBWQJC5wx1ebC_uLUgCxtcgHEkjGxyFyhUG_oMb4s/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9pLnBp/bmltZy5jb20vb3Jp/Z2luYWxzL2Y1L2Uz/LzE1L2Y1ZTMxNWZi/N2IzOWEwN2JhOGI2/ZDkwYmNiZGU4OTg3/LmpwZw?w=800",
            "https://imgs.search.brave.com/ZepxWxMI43H4ckCMTwvqW2FnY29BTGFLE3Lp5NFHqsc/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9jZG4u/c2FuaXR5LmlvL2lt/YWdlcy9ubHBxdHMz/ei9wcm9kdWN0aW9u/LzFiZmRhNDI5Njlj/OTc3NTVlMGJlNTY2/MDE1YzI2Yzk5YmY2/NTEyMWUtMTAyNHg2/ODMuanBnP2F1dG89/Zm9ybWF0?w=800"
        ]
    },
    {
        id: 7, name: "Hussain Sagar", district: "Hyderabad",
        circuit: "Nature", lat: 17.4239, lng: 78.4738,
        description: "A famous lake featuring the iconic Buddha statue and beautiful waterfront views.",
        image: "https://imgs.search.brave.com/882tipVB4Xnp2WpPJyvjfkufovfoOxU9H4GbElu3Zio/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly90aHVt/YnMuZHJlYW1zdGlt/ZS5jb20vYi9idWRk/aGEtc3RhdHVlLWh5/ZGVyYWJhZC1pbmRp/YS1hdWd1c3QtdGFs/bGVzdC1tb25vbGl0/aGljLXdvcmxkLWF1/Z3VzdC1pbmRpYS00/ODgxMTYxNC5qcGc?w=800",
        gallery: [
            "https://imgs.search.brave.com/jFJBVnfUsperL_e3sdjg9cPmUGL1xRwOa4D6ghhr4MM/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly93d3cu/c2h1dHRlcnN0b2Nr/LmNvbS9pbWFnZS1w/aG90by9oeWRlcmFi/YWQtaW5kaWEtYXVn/dXN0LTE4YnVkZGhh/LXN0YXR1ZS0yNjBu/dy0yNDUxODA0NzAu/anBn?w=800",
            "https://imgs.search.brave.com/oNQ0juOifgQJv7-toyO0HSwx3LZNbw25GmhBaSm3F_c/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9pbWcu/dHJhdmVsdHJpYW5n/bGUuY29tL2Jsb2cv/d3AtY29udGVudC91/cGxvYWRzLzIwMjQv/MDcvaHVzc2Fpbi1z/YWdhci1sYWtlMS5q/cGc?w=800",
            "https://imgs.search.brave.com/Msb9NOSGWNzXoCdcZcwms4NA9jBqEpJShbYyjSFhzlA/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly90NC5m/dGNkbi5uZXQvanBn/LzEyLzI5LzU1LzIz/LzM2MF9GXzEyMjk1/NTIzMjNfa3FjZnlv/S1RXNFk5TkdRV3U5/VWdvWnhKUlVteGhR/cUEuanBn?w=800"
        ]
    },
    {
        id: 8, name: "Alampur Temples", district: "Jogulamba Gadwal",
        circuit: "Temple", lat: 15.8794, lng: 78.1335,
        description: "An ancient temple complex known for Chalukyan architecture.",
        image: "https://imgs.search.brave.com/DlmmldyV_fGECOtC_DrUXODPmt636Ug-h9Edu737Hrc/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly90ZW1w/bGUueWF0cmFkaGFt/Lm9yZy9wdWJsaWMv/UHJvZHVjdC90ZW1w/bGUvdGVtcGxlXzZY/OHdUcGVHXzIwMjUw/NzExMTYwOTAyMC53/ZWJw?w=800",
        gallery: [
            "https://imgs.search.brave.com/1JTKq5BKRiEMybz9NeVvBwtv4WxqLPpBv7prTociB24/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9oaW5k/dW1hbmRpcnlhdHJh/LmNvbS9fbmV4dC9z/dGF0aWMvbWVkaWEv/dGVtcGxlLW92ZXJ2/aWV3LjY3Yzc1MmYx/LndlYnA?w=800",
            "https://imgs.search.brave.com/KyUw8Q2IzfqxFS3si1dNROKEEpJUfYVG03ff6eBKMn8/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9pMC53/cC5jb20vd3d3LnJ2/YXRlbXBsZXMuY29t/L3dwLWNvbnRlbnQv/dXBsb2Fkcy8yMDE4/LzAyL2pvZ3VsYW1i/YS0xLTIuanBnP2Zp/dD05MzAsNjIwJnNz/bD0x?w=800",
            "https://imgs.search.brave.com/O2JeGQmEA77bOjJKd-Ni1P8YdFa3o0Y7S08aqB6WW3o/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly90My5m/dGNkbi5uZXQvanBn/LzAyLzA2Lzc5LzQ0/LzM2MF9GXzIwNjc5/NDQ0MF9NMzNxZkpz/bko0RlBDSHpia3Zo/bEg2QzN1WE1nN1JH/Si5qcGc?w=800"
        ]
    }
];

let tourismMap = null;
let virtualMap = null;
let wishList = JSON.parse(localStorage.getItem("wanderWishlist") || "[]");
let reviews = JSON.parse(localStorage.getItem("wanderReviews") || "[]");

const escapeHTML = value => String(value).replace(/[&<>"']/g, c => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;",
    '"': "&quot;", "'": "&#39;"
})[c]);

function getPlace(name) {
    return places.find(p => p.name === name);
}

function optionsHTML() {
    return places.map(p =>
        `<option value="${escapeHTML(p.name)}">${escapeHTML(p.name)}</option>`
    ).join("");
}

function heading(title, description) {
    return `<div class="page-heading">
        <h1>${title}</h1><p>${description}</p>
    </div>`;
}

function panel(content) {
    return `<div class="panel">${content}</div>`;
}

function selectField(label, id) {
    return `<label class="field">${label}
        <select id="${id}">${optionsHTML()}</select>
    </label>`;
}

function result(id, html) {
    const el = document.getElementById(id);
    if (el) el.innerHTML = html;
}

function distanceBetween(a, b) {
    const rad = n => n * Math.PI / 180;
    const dLat = rad(b.lat - a.lat);
    const dLng = rad(b.lng - a.lng);
    const x = Math.sin(dLat / 2) ** 2 +
        Math.cos(rad(a.lat)) * Math.cos(rad(b.lat)) *
        Math.sin(dLng / 2) ** 2;
    return 6371 * 2 * Math.atan2(Math.sqrt(x), Math.sqrt(1 - x));
}

// DESTINATION CARDS

function destinationCards() {
    return `<div class="places-grid">
        ${places.map(p => `
            <article class="place-card">
                <div class="image-wrap">
                    <img class="place-image" src="${p.image}"
                         alt="${escapeHTML(p.name)}"
                         onerror="this.src='https://images.unsplash.com/photo-1519681393784-d120267933ba?w=800'">
                    <span class="place-tag">${escapeHTML(p.circuit)}</span>
                </div>
                <div class="place-info">
                    <h3>${escapeHTML(p.name)}</h3>
                    <p> ${escapeHTML(p.district)}, Telangana</p>
                    <p>${escapeHTML(p.description)}</p>
                    <a href="#gallery" class="card-link"
                       data-gallery-place="${escapeHTML(p.name)}">Explore Photos →</a>
                </div>
            </article>
        `).join("")}
    </div>`;
}

// HOME

function homePage() {
    return `
        <section class="hero">
            <div class="hero-content">
                <span class="eyebrow">THE LAND OF HERITAGE & CULTURE</span>
                <h1>Discover the<br>Beauty of Telangana</h1>
                <p>From magnificent forts to timeless temples, explore the stories, culture and unforgettable destinations of Telangana.</p>
                <a href="#explore" class="primary-btn">Explore Destinations →</a>
            </div>
        </section>

        <section class="section">
            <h2 class="section-title">Discover Incredible Places</h2>
            <p class="section-description">Explore the iconic destinations of Telangana.</p>
            ${destinationCards()}
        </section>

        <section class="section">
            <h2 class="section-title">Plan Your Journey</h2>
            <p class="section-description">Everything you need for a memorable trip.</p>
            <div class="quick-grid">
                <a href="#route">✈ Smart Route Planner</a>
                <a href="#budget">₹ Budget Calculator</a>
                <a href="#weather">☀ Weather Updates</a>
                <a href="#wishlist">♡ My Wishlist</a>
            </div>
        </section>`;
}

// EXPLORE

function explorePage() {
    return `${heading("Explore Telangana", "Find your next unforgettable destination.")}${destinationCards()}`;
}

// GALLERY

function galleryPage() {
    return `${heading("Destination Gallery", "Choose a place to explore its photo collection.")}
        ${panel(`
            <div class="gallery-controls">
                <label class="field">Select Destination
                    <select id="galleryPlace">${optionsHTML()}</select>
                </label>
            </div>
            <div id="galleryPhotos" class="gallery-grid"></div>
        `)}`;
}

function renderGallery() {
    const select = document.getElementById("galleryPlace");
    if (!select) return;
    const place = getPlace(select.value);
    const container = document.getElementById("galleryPhotos");
    container.innerHTML = place.gallery.map((src, i) => `
        <div class="gallery-item">
            <img src="${src}" alt="${escapeHTML(place.name)} photo ${i + 1}"
                onerror="this.parentElement.style.display='none'">
            <h3>${escapeHTML(place.name)} · Photo ${i + 1}</h3>
        </div>
    `).join("");
}

// ABOUT

function aboutPage() {
    return `${heading("About WanderTrail", "Your companion to discover Telangana.")}
        ${panel(`
            <h2>Explore. Experience. Remember.</h2>
            <p>WanderTrail is a tourism discovery platform designed to introduce visitors to the heritage, culture, architecture and natural beauty of Telangana.</p>
            <h3>Our Purpose</h3>
            <p>We bring destination information and useful trip-planning tools together in one place.</p>
            <h3>Discover Telangana</h3>
            <p>Explore historic monuments, traditional festivals, cultural landmarks and beautiful destinations.</p>
        `)}`;
}

// LOGIN

function loginPage() {
    return `${heading("Welcome to WanderTrail", "Sign in or create an account to personalize your travel experience.")}
        <div class="login-layout">
            <div class="login-art">
                <span class="eyebrow">YOUR NEXT JOURNEY STARTS HERE</span>
                <h2>Travel More.<br>Discover More.</h2>
                <p>Explore the stories of Telangana.</p>
            </div>
            <div class="login-form">
                <h2 id="authTitle">Welcome Back</h2>
                <p class="muted" id="authDescription">Login to your travel space.</p>
                <form id="authForm">
                    <label class="field">Full Name
                        <input id="authName" type="text" placeholder="Your name" required>
                    </label>
                    <label class="field">Email Address
                        <input id="authEmail" type="email" placeholder="name@example.com" required>
                    </label>
                    <label class="field">Password
                        <input id="authPassword" type="password" minlength="4" placeholder="Enter password" required>
                    </label>
                    <button type="submit" id="authSubmit">Login</button>
                </form>
                <p id="authSwitch" class="muted" style="margin-top:18px">
                    New here? <a href="#" id="switchAuth">Create an account</a>
                </p>
                <div id="authResult" class="result"></div>
                <small>Demo interface only. Do not enter real or sensitive passwords.</small>
            </div>
        </div>`;
}

// MAP

function mapPage() {
    return `${heading("Telangana Tourism Map", "Discover destinations across the state.")}
        ${panel(`<div id="map"></div>
        <div id="mapInfo" class="result">Select a marker to explore a destination.</div>`)}`;
}

// ROUTE

function routePage() {
    return `${heading("Smart Route Planner", "Plan a journey between your favourite destinations.")}
        <div class="route-banner">
            <span class="eyebrow">YOUR TELANGANA JOURNEY</span>
            <h2>Every destination has a story.</h2>
            <p>Choose your starting point and destination.</p>
        </div>
        ${panel(`
            ${selectField("Starting Point", "routeFrom")}
            ${selectField("Destination", "routeTo")}
            <button id="routeButton">Find Route</button>
            <div id="routeResult" class="result"></div>
        `)}`;
}

// DISTANCE

function distancePage() {
    return `${heading("Distance Calculator", "Estimate the straight-line distance between destinations.")}
        ${panel(`
            ${selectField("From", "distanceFrom")}
            ${selectField("To", "distanceTo")}
            <button id="distanceButton">Calculate Distance</button>
            <div id="distanceResult" class="result"></div>
        `)}`;
}

// TRAVEL TIME

function timePage() {
    return `${heading("Travel Time Estimator", "Estimate journey time using an approximate road distance.")}
        ${panel(`
            ${selectField("Starting Point", "timeFrom")}
            ${selectField("Destination", "timeTo")}
            <label class="field">Average Speed (km/h)
                <input type="number" id="speed" value="50" min="1" max="150">
            </label>
            <button id="timeButton">Estimate Time</button>
            <div id="timeResult" class="result"></div>
        `)}`;
}

// WISHLIST

function wishlistPage() {
    return `${heading("My Wishlist", "Keep your favourite destinations in one place.")}
        ${panel(`
            ${selectField("Choose Destination", "wishPlace")}
            <button id="addWish">Add to Wishlist</button>
            <div id="wishList" class="result"></div>
        `)}`;
}

function renderWishlist() {
    const box = document.getElementById("wishList");
    if (!box) return;
    box.innerHTML = wishList.length
        ? wishList.map(name => `<p>♡ ${escapeHTML(name)}
            <button data-remove-wish="${escapeHTML(name)}">Remove</button></p>`).join("")
        : "Your wishlist is empty. Add a destination to get started.";
}

// TRIP

function tripPage() {
    return `${heading("Trip Planner", "Create a simple travel plan.")}
        ${panel(`
            ${selectField("Destination", "tripPlace")}
            <label class="field">Travel Date
                <input type="date" id="tripDate" required>
            </label>
            <label class="field">Number of Days
                <input type="number" id="tripDays" min="1" value="2">
            </label>
            <button id="saveTrip">Create Trip</button>
            <div id="tripResult" class="result"></div>
        `)}`;
}

// BUDGET

function budgetPage() {
    return `${heading("Travel Budget Calculator", "Estimate your trip expenses.")}
        ${panel(`
            <label class="field">Number of People
                <input type="number" id="people" min="1" value="1">
            </label>
            <label class="field">Travel Cost per Person (₹)
                <input type="number" id="travelCost" min="0" value="1000">
            </label>
            <label class="field">Hotel Cost per Night (₹)
                <input type="number" id="hotelCost" min="0" value="1500">
            </label>
            <label class="field">Number of Nights
                <input type="number" id="nights" min="0" value="1">
            </label>
            <label class="field">Food Cost per Person (₹)
                <input type="number" id="foodCost" min="0" value="500">
            </label>
            <button id="budgetButton">Calculate Budget</button>
            <div id="budgetResult" class="result"></div>
        `)}`;
}

// WEATHER

function weatherPage() {
    return `${heading("Weather Information", "Check current weather at a destination.")}
        ${panel(`
            ${selectField("Destination", "weatherPlace")}
            <button id="weatherButton">Check Weather</button>
            <div id="weatherResult" class="result">Weather details will appear here.</div>
        `)}`;
}

async function loadWeather() {
    const p = getPlace(document.getElementById("weatherPlace").value);
    result("weatherResult", "Loading weather...");
    try {
        const url = `https://api.open-meteo.com/v1/forecast?latitude=${p.lat}&longitude=${p.lng}&current=temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m&timezone=auto`;
        const response = await fetch(url);
        if (!response.ok) throw new Error();
        const data = await response.json();
        const w = data.current;
        result("weatherResult", `
            <h3>☀ ${w.temperature_2m}°C</h3>
            <p>Feels like: ${w.apparent_temperature}°C</p>
            <p>Humidity: ${w.relative_humidity_2m}%</p>
            <p>Wind speed: ${w.wind_speed_10m} km/h</p>
            <p>Weather code: ${w.weather_code}</p>
            <small>Source: Open-Meteo. Conditions may change.</small>
        `);
    } catch {
        result("weatherResult", "Weather data unavailable. Please try again.");
    }
}

// SUNRISE AND SUNSET

function sunPage() {
    return `${heading("Sunrise & Sunset", "Check approximate daylight timings.")}
        ${panel(`
            ${selectField("Destination", "sunPlace")}
            <label class="field">Date
                <input type="date" id="sunDate">
            </label>
            <button id="sunButton">Check Timings</button>
            <div id="sunResult" class="result"></div>
        `)}`;
}

async function loadSun() {
    const p = getPlace(document.getElementById("sunPlace").value);
    const date = document.getElementById("sunDate").value;
    if (!date) return result("sunResult", "Please select a date.");
    result("sunResult", "Loading...");
    try {
        const url = `https://api.open-meteo.com/v1/forecast?latitude=${p.lat}&longitude=${p.lng}&daily=sunrise,sunset&timezone=auto&start_date=${date}&end_date=${date}`;
        const response = await fetch(url);
        if (!response.ok) throw new Error();
        const data = await response.json();
        result("sunResult", `<h3>☀ Sunrise: ${data.daily.sunrise[0].split("T")[1]}</h3>
            <h3>Sunset: ${data.daily.sunset[0].split("T")[1]}</h3>`);
    } catch {
        result("sunResult", "Sunrise and sunset details unavailable.");
    }
}

// SEASON

function seasonPage() {
    return `${heading("Best Time to Visit Telangana", "Choose your travel season.")}
        ${panel(`
            <h3>❄ October – February</h3>
            <p>Generally pleasant weather for sightseeing and heritage visits.</p>
            <hr>
            <h3>☀ March – May</h3>
            <p>Hot summer conditions. Consider early morning and evening outings.</p>
            <hr>
            <h3>🌧 June – September</h3>
            <p>Monsoon season brings greenery. Check local weather before travelling.</p>
        `)}`;
}

// CHATBOT DEMO

function chatPage() {
    return `${heading("Telangana Travel Assistant", "Ask questions about destinations in this demo assistant.")}
        ${panel(`
            <div id="chatMessages" class="result">Assistant: Welcome! Ask me about Telangana destinations.</div>
            <label class="field">Your question
                <input id="chatQuestion" placeholder="Where is Charminar?">
            </label>
            <button id="chatButton">Send Message</button>
        `)}`;
}

// VIRTUAL TOUR

function virtualPage() {
    return `${heading("Virtual Destination Explorer", "Explore locations on an interactive map.")}
        ${panel(`
            ${selectField("Choose Destination", "virtualPlace")}
            <div id="virtualMap"></div>
            <div id="virtualInfo" class="result"></div>
        `)}`;
}

// REVIEWS

function reviewsPage() {
    return `${heading("Ratings & Reviews", "Share your experience of a destination.")}
        ${panel(`
            ${selectField("Destination", "reviewPlace")}
            <label class="field">Rating
                <select id="reviewRating">
                    <option value="5">★★★★★ Excellent</option>
                    <option value="4">★★★★ Very Good</option>
                    <option value="3">★★★ Good</option>
                    <option value="2">★★ Average</option>
                    <option value="1">★ Poor</option>
                </select>
            </label>
            <label class="field">Your Review
                <textarea id="reviewText" placeholder="Write your experience..."></textarea>
            </label>
            <button id="reviewButton">Submit Review</button>
            <div id="reviewResult" class="result"></div>
            <div id="reviewList"></div>
        `)}`;
}

function renderReviews() {
    const box = document.getElementById("reviewList");
    if (!box) return;
    box.innerHTML = reviews.length
        ? reviews.map(r => `<div class="review-card">
            <b>${escapeHTML(r.place)}</b> · ${"★".repeat(r.rating)}
            <p>${escapeHTML(r.text)}</p>
        </div>`).join("")
        : "<p class='muted'>No reviews yet.</p>";
}

// FESTIVALS

function festivalsPage() {
    return `${heading("Telangana Festival Calendar", "Celebrate the traditions and culture of Telangana.")}
        ${panel(`
            <h3> Bathukamma</h3>
            <p>A floral festival celebrated with traditional songs and gatherings.</p>
            <hr>
            <h3> Bonalu</h3>
            <p>A traditional festival celebrated in honour of Goddess Mahakali.</p>
            <hr>
            <h3> Sammakka Saralamma Jatara</h3>
            <p>A major tribal religious gathering at Medaram.</p>
            <hr>
            <h3> Ugadi</h3>
            <p>The Telugu New Year festival.</p>
        `)}`;
}

// NEARBY SERVICES

function servicesPage() {
    return `${heading("Nearby Services", "Find services around your selected destination.")}
        ${panel(`
            ${selectField("Destination", "servicePlace")}
            <label class="field">Service Type
                <select id="serviceType">
                    <option>Hotels</option>
                    <option>Restaurants</option>
                    <option>Hospitals</option>
                    <option>Petrol Pumps</option>
                </select>
            </label>
            <button id="serviceButton">Find Nearby</button>
            <div id="serviceResult" class="result"></div>
        `)}`;
}

// ACHIEVEMENTS

function achievementsPage() {
    return `${heading("Travel Achievements", "Celebrate the places you discover.")}
        ${panel(`
            <h3> First Discovery</h3><p>Explore your first destination.</p><hr>
            <h3>Heritage Explorer</h3><p>Discover a historic monument.</p><hr>
            <h3> Temple Explorer</h3><p>Visit a historic temple.</p><hr>
            <h3> Telangana Traveller</h3><p>Explore five destinations.</p>
        `)}`;
}

// HISTORY

function historyPage() {
    return `${heading("Historical Timeline", "A glimpse into the history of Telangana.")}
        ${panel(`
            <div class="timeline-item"><h3>Satavahana Period</h3><p>An influential ancient Deccan dynasty.</p></div>
            <div class="timeline-item"><h3>Kakatiya Dynasty</h3><p>Known for Warangal and remarkable temples.</p></div>
            <div class="timeline-item"><h3>Qutb Shahi Period</h3><p>A major period in Hyderabad's history.</p></div>
            <div class="timeline-item"><h3>Asaf Jahi Period</h3><p>The Nizams ruled Hyderabad.</p></div>
            <div class="timeline-item"><h3>2 June 2014</h3><p>Telangana became a separate state of India.</p></div>
        `)}`;
}

// PAGE REGISTRY

const pages = {
    home: homePage,
    explore: explorePage,
    gallery: galleryPage,
    about: aboutPage,
    login: loginPage,
    map: mapPage,
    route: routePage,
    distance: distancePage,
    time: timePage,
    wishlist: wishlistPage,
    trip: tripPage,
    budget: budgetPage,
    weather: weatherPage,
    sun: sunPage,
    season: seasonPage,
    chat: chatPage,
    virtual: virtualPage,
    reviews: reviewsPage,
    festivals: festivalsPage,
    services: servicesPage,
    achievements: achievementsPage,
    history: historyPage
};

// MAPS

function initializeMap() {
    const el = document.getElementById("map");
    if (!el || typeof L === "undefined") return;

    tourismMap = L.map(el).setView([17.9, 79.2], 7);

    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        attribution: "&copy; OpenStreetMap contributors"
    }).addTo(tourismMap);

    places.forEach(p => {
        L.marker([p.lat, p.lng]).addTo(tourismMap)
            .bindPopup(`<b>${escapeHTML(p.name)}</b><br>${escapeHTML(p.district)}`)
            .on("click", () => result("mapInfo",
                `<h3>${escapeHTML(p.name)}</h3><p>${escapeHTML(p.description)}</p>`));
    });

    setTimeout(() => tourismMap?.invalidateSize(), 250);
}

function initializeVirtualMap() {
    if (!document.getElementById("virtualMap") || typeof L === "undefined") return;

    const p = places[0];
    virtualMap = L.map("virtualMap").setView([p.lat, p.lng], 12);

    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        attribution: "&copy; OpenStreetMap contributors"
    }).addTo(virtualMap);

    updateVirtualMap();
    setTimeout(() => virtualMap?.invalidateSize(), 250);
}

function updateVirtualMap() {
    const p = getPlace(document.getElementById("virtualPlace")?.value);
    if (!p || !virtualMap) return;

    virtualMap.setView([p.lat, p.lng], 13);
    L.marker([p.lat, p.lng]).addTo(virtualMap)
        .bindPopup(escapeHTML(p.name)).openPopup();

    result("virtualInfo", `<h3>${escapeHTML(p.name)}</h3>
        <p>${escapeHTML(p.description)}</p>
        <p>District: ${escapeHTML(p.district)}</p>`);
}

// PAGE RENDER

function renderPage() {
    const name = location.hash.slice(1) || "home";

    if (tourismMap) {
        tourismMap.remove();
        tourismMap = null;
    }

    if (virtualMap) {
        virtualMap.remove();
        virtualMap = null;
    }

    app.innerHTML = (pages[name] || homePage)();

    document.querySelectorAll(".sidebar > a").forEach(a => {
        a.classList.toggle("active", a.getAttribute("href") === "#" + name);
    });

    if (name === "map") initializeMap();
    if (name === "virtual") initializeVirtualMap();
    if (name === "gallery") renderGallery();
    if (name === "wishlist") renderWishlist();
    if (name === "reviews") renderReviews();
}

// EVENTS

document.addEventListener("click", async e => {
    const category = e.target.closest(".menu-category");
    if (category) {
        category.parentElement.classList.toggle("open");
    }

    if (e.target.closest("#menuToggle")) {
        document.getElementById("sidebar").classList.toggle("show");
    }

    if (e.target.closest("#addWish")) {
        const name = document.getElementById("wishPlace").value;
        if (!wishList.includes(name)) wishList.push(name);
        localStorage.setItem("wanderWishlist", JSON.stringify(wishList));
        renderWishlist();
    }

    const remove = e.target.closest("[data-remove-wish]");
    if (remove) {
        wishList = wishList.filter(n => n !== remove.dataset.removeWish);
        localStorage.setItem("wanderWishlist", JSON.stringify(wishList));
        renderWishlist();
    }

    if (e.target.closest("#distanceButton")) {
        const a = getPlace(document.getElementById("distanceFrom").value);
        const b = getPlace(document.getElementById("distanceTo").value);
        if (a.name === b.name) return result("distanceResult", "Choose two different destinations.");
        result("distanceResult", `<h3>${distanceBetween(a, b).toFixed(2)} km</h3><p>Approximate straight-line distance.</p>`);
    }

    if (e.target.closest("#routeButton")) {
        const a = getPlace(document.getElementById("routeFrom").value);
        const b = getPlace(document.getElementById("routeTo").value);
        if (a.name === b.name) return result("routeResult", "Choose two different places.");
        const km = distanceBetween(a, b);
        result("routeResult", `<h3>${escapeHTML(a.name)} → ${escapeHTML(b.name)}</h3>
            <p>Approximate straight-line distance: ${km.toFixed(1)} km</p>
            <p>Road distance may differ. Use a navigation service for actual directions.</p>
            <a class="card-link" target="_blank" rel="noopener" href="https://www.google.com/maps/dir/${a.lat},${a.lng}/${b.lat},${b.lng}">Open directions in Google Maps →</a>`);
    }

    if (e.target.closest("#timeButton")) {
        const a = getPlace(document.getElementById("timeFrom").value);
        const b = getPlace(document.getElementById("timeTo").value);
        const speed = Number(document.getElementById("speed").value);
        if (a.name === b.name || speed <= 0) return result("timeResult", "Choose different places and a valid speed.");
        const hours = distanceBetween(a, b) * 1.25 / speed;
        result("timeResult", `<h3>${Math.floor(hours)} hours ${Math.round((hours % 1) * 60)} minutes</h3><p>Rough estimate only; traffic and road conditions can change travel time.</p>`);
    }

    if (e.target.closest("#budgetButton")) {
        const ids = ["people", "travelCost", "hotelCost", "nights", "foodCost"];
        const v = ids.map(id => Number(document.getElementById(id).value));
        if (v.some(n => !Number.isFinite(n) || n < 0) || v[0] < 1) return result("budgetResult", "Enter valid positive values.");
        const total = v[0] * v[1] + v[2] * v[3] + v[0] * v[4];
        result("budgetResult", `<h3>Estimated Total: ₹${total.toLocaleString("en-IN")}</h3><p>For ${v[0]} traveller(s).</p>`);
    }

    if (e.target.closest("#saveTrip")) {
        const date = document.getElementById("tripDate").value;
        const days = Number(document.getElementById("tripDays").value);
        const place = document.getElementById("tripPlace").value;
        if (!date || days < 1) return result("tripResult", "Enter a valid date and number of days.");
        result("tripResult", `<h3>✈ Your trip is planned!</h3><p>Destination: ${escapeHTML(place)}</p><p>Date: ${escapeHTML(date)}</p><p>Duration: ${days} days</p>`);
    }

    if (e.target.closest("#weatherButton")) loadWeather();
    if (e.target.closest("#sunButton")) loadSun();

    if (e.target.closest("#serviceButton")) {
        const p = getPlace(document.getElementById("servicePlace").value);
        const type = document.getElementById("serviceType").value;
        const query = encodeURIComponent(`${type} near ${p.name}, Telangana`);
        result("serviceResult", `<p>Search for ${escapeHTML(type)} near ${escapeHTML(p.name)}.</p><a class="card-link" target="_blank" rel="noopener" href="https://www.google.com/maps/search/${query}">Find on Google Maps →</a>`);
    }

    if (e.target.closest("#chatButton")) {
        const input = document.getElementById("chatQuestion");
        const question = input.value.trim();
        if (!question) return;
        const match = places.find(p => question.toLowerCase().includes(p.name.toLowerCase()));
        const answer = match
            ? `${match.name} is located in ${match.district}. ${match.description}`
            : "I can help with these destinations: " + places.map(p => p.name).join(", ") + ". Ask about a place by name.";
        const box = document.getElementById("chatMessages");
        box.innerHTML += `<p><b>You:</b> ${escapeHTML(question)}</p><p><b>Assistant:</b> ${escapeHTML(answer)}</p>`;
        input.value = "";
    }

    if (e.target.closest("#reviewButton")) {
        const place = document.getElementById("reviewPlace").value;
        const rating = Number(document.getElementById("reviewRating").value);
        const text = document.getElementById("reviewText").value.trim();
        if (!text) return result("reviewResult", "Please write a review.");
        reviews.unshift({ place, rating, text });
        localStorage.setItem("wanderReviews", JSON.stringify(reviews));
        document.getElementById("reviewText").value = "";
        result("reviewResult", "Thank you! Your review has been saved in this browser.");
        renderReviews();
    }

    const galleryLink = e.target.closest("[data-gallery-place]");
    if (galleryLink) {
        sessionStorage.setItem("galleryPlace", galleryLink.dataset.galleryPlace);
    }

    if (e.target.closest("#switchAuth")) {
        e.preventDefault();
        const form = document.getElementById("authForm");
        const register = document.getElementById("authTitle").textContent === "Welcome Back";
        document.getElementById("authTitle").textContent = register ? "Create Account" : "Welcome Back";
        document.getElementById("authDescription").textContent = register ? "Join the WanderTrail community." : "Login to your travel space.";
        document.getElementById("authName").style.display = register ? "block" : "none";
        document.getElementById("authSubmit").textContent = register ? "Register" : "Login";
        document.getElementById("authSwitch").innerHTML = register
            ? 'Already registered? <a href="#" id="switchAuth">Login</a>'
            : 'New here? <a href="#" id="switchAuth">Create an account</a>';
        form.dataset.mode = register ? "register" : "login";
    }

    if (e.target.closest("#authSubmit")) {
        // Handled by form submit below.
    }
});

// SELECT CHANGE

document.addEventListener("change", e => {
    if (e.target.id === "galleryPlace") renderGallery();
    if (e.target.id === "virtualPlace") updateVirtualMap();
});

// AUTH DEMO FORM

document.addEventListener("submit", e => {
    if (e.target.id !== "authForm") return;
    e.preventDefault();
    const mode = e.target.dataset.mode || "login";
    const name = document.getElementById("authName").value.trim();
    const email = document.getElementById("authEmail").value.trim();
    if (mode === "register" && !name) return result("authResult", "Enter your name.");
    result("authResult", mode === "register"
        ? `Welcome, ${escapeHTML(name)}! This is a front-end demo; account creation needs a secure backend.`
        : `Login form validated for ${escapeHTML(email)}. Connect a secure backend for real authentication.`);
});

// ROUTE CHANGE

window.addEventListener("hashchange", () => {
    document.getElementById("sidebar")?.classList.remove("show");
    renderPage();
});

// INITIAL LOAD

document.addEventListener("DOMContentLoaded", renderPage);
if (document.readyState !== "loading") renderPage();

